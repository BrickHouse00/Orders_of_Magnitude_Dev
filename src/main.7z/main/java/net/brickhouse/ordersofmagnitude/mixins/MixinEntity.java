//Credit for this function goes to gigabit101 for his work on Shrink.  This class was utilized while I work out a way to handle AABB issues through a Forge implementation

//isPoseClear fires constantly.  There must be a better way to handle the needs of this function and reduce computational load.  Setting the AABB is doable with the right logic, but this function does help with overhead collision.  Maybe using the deflate command when recalcing the BB
package net.brickhouse.ordersofmagnitude.mixins;

import net.brickhouse.ordersofmagnitude.config.OMServerConfig;
import net.brickhouse.ordersofmagnitude.sizechange.SizeChangeCapability;
import net.brickhouse.ordersofmagnitude.sizechange.SizeUtility;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class MixinEntity {

    @Shadow public abstract double getX();

    @Shadow public abstract double getY();

    @Shadow public abstract double getZ();

    @Shadow public Level level;
    @Shadow public abstract EntityDimensions getDimensions(Pose pPose);

    @Inject(at = @At("RETURN"), method = "canEnterPose", cancellable = true)
    public void isPoseClear(Pose pose, CallbackInfoReturnable<Boolean> cir) {
        Entity entity = (Entity) (Object) this;
        if(entity instanceof Player){
            LivingEntity livingEntity = (LivingEntity) entity;
            livingEntity.getCapability(SizeChangeCapability.INSTANCE).ifPresent(sizeChange ->{
               if(sizeChange.getIsScaled()){
                   float scale = (float) sizeChange.getCurrentScale();
                   EntityDimensions entityDimensions = this.getDimensions(pose);
                   entityDimensions = entityDimensions.scale(scale);
                   float f = entityDimensions.width / 2.0F;
                   Vec3 vector3d = new Vec3(this.getX() - (double)f, this.getY(), this.getZ() - (double)f);
                   Vec3 vector3d1 = new Vec3(this.getX() + (double)f, this.getY() + (double)entityDimensions.height, this.getZ() + (double)f);
                   AABB box = new AABB(vector3d, vector3d1);
                   cir.setReturnValue(this.level.noCollision(livingEntity, box.deflate(1.0E-7D)));
               }
            });
        }
    }

    @Inject(method = "push(Lnet/minecraft/world/entity/Entity;)V", at = @At(value="INVOKE", target = "Lnet/minecraft/world/entity/Entity;push(DDD)V", ordinal = 0), cancellable = true)
    public void stompDamage(Entity pEntity, CallbackInfo ci){
        if((Entity)(Object)this instanceof Player player){
            System.out.println("Player is this");
        }
        if(pEntity instanceof Player player1){
            System.out.println("Player is pEntity");
        }
        Level world = ((Entity)(Object)this).level;
        //if(!world.isClientSide()){
            double thisEntitySize = SizeUtility.getScale((Entity)(Object)this);
            double passedEntitySize = SizeUtility.getScale(pEntity);
            if((Entity)(Object)this instanceof Player || pEntity instanceof Player){
                System.out.println("this: " + (Entity)(Object)this + "thisEntitySize: " + thisEntitySize + " pEntity: " + pEntity + " passedEntitySize: " + passedEntitySize);
            }
            if(thisEntitySize/passedEntitySize >= 9.99D){               //set it slightly less than 10x to grab any significant figures
                System.out.println("" + (Entity)(Object)this + " can stomp on " + pEntity);
                int playerStompSetting = OMServerConfig.PLAYER_STOMP_SETTING.get();
                if(pEntity instanceof Player && playerStompSetting < 2){
                    if(playerStompSetting==1){
                        pEntity.hurt(DamageSource.GENERIC, ((LivingEntity) pEntity).getMaxHealth()*0.1F);
                    }
                } else {
                    pEntity.hurt(DamageSource.GENERIC, ((LivingEntity) pEntity).getMaxHealth());
                }
            }
        //}
    }

    @Inject(at = @At("HEAD"), method = "spawnSprintParticle", cancellable = true)
    public void cancelWhenShrunk(CallbackInfo ci){
        if (SizeUtility.getScale((Entity) (Object) this) < 1.0) {
            ci.cancel();
        }
    }

    //TODO Fix these values.  The movement is way too slow at small scales
    //Updated the position vector.  There are three places in the move() function that store the position vector after some calculation: limitPistonMovement, maybeBackOffFromEdge, and multiply(stuckSpeedMultiplier)
    //maybeBackOffFromEdge is the last one that calculates and stores the value again.  After that, the variable is only used.
    @ModifyVariable(method="move", at = @At("STORE"))
    public Vec3 onMove(Vec3 pPos){
        Entity entity = (Entity)(Object) this;
        if(entity instanceof LivingEntity livingEntity) {
            double scale = (double) SizeUtility.getScale(livingEntity); //.getBbHeight()/1.8;
            if (scale > 1.0) {
                scale *= 0.75F;             //for bigs, don't let them speed up too much.  Lower factor dampens more
            } else if (scale < 0.002) {     //for micros, we need to scale it up a bit more or else they spend years trying to move around
                scale *= 20;
            } else if (scale < 0.03) {      //tinies still need a bump
                scale *= 5;
            }else if (scale < 0.12) {
                scale*=2;                   //for smalls, don't let the factor get too low.  It's oppressively slow
            }
            pPos = pPos.multiply(scale, scale, scale);
        }
        return pPos;
    }
}
