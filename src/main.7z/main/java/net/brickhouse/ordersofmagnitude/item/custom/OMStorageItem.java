package net.brickhouse.ordersofmagnitude.item.custom;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.capabilities.ICapabilityProvider;

import javax.annotation.Nullable;

public class OMStorageItem extends Item {
    private int numSlots;
    public OMStorageItem(Properties pProperties, int pSlotCount) {
        super(pProperties);
        numSlots = pSlotCount;
    }

    public ICapabilityProvider initCapabilities(ItemStack stack, @Nullable CompoundTag nbt){

        return new OMItemStackHandler(stack, numSlots);
    }
}
