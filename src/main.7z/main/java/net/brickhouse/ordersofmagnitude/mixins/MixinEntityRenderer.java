package net.brickhouse.ordersofmagnitude.mixins;

import net.brickhouse.ordersofmagnitude.sizechange.SizeUtility;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(EntityRenderer.class)
public abstract class MixinEntityRenderer {

    /*
    //Still not fixing my render issue.  Not even sure when this is firing as the system out isn't printing
    @ModifyVariable(method = "shouldRender", ordinal = 0, at=@At(value="STORE"))
    private AABB shouldRenderScaledHeight(AABB aabb, Entity pLivingEntity) {
        aabb = aabb.inflate(0.0, -(pLivingEntity.getBbHeight()/1.8), 0.0);
        System.out.print("Should render aabb: " + aabb);
        return aabb;
    }*/

    @ModifyVariable(method = "renderNameTag", ordinal = 0, at=@At(value="STORE"))
    private float renderNameTagScaledHeight(float f, Entity pEntity){
        return f = pEntity.getBbHeight()/SizeUtility.getScale(pEntity);
    }
}
