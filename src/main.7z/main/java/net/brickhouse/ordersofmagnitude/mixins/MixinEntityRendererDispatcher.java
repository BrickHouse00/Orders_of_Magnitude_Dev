package net.brickhouse.ordersofmagnitude.mixins;

import com.mojang.blaze3d.vertex.PoseStack;
import net.brickhouse.ordersofmagnitude.sizechange.SizeUtility;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(EntityRenderDispatcher.class)
public abstract class MixinEntityRendererDispatcher {


    //Scale the shadow plox
    @ModifyArg(method="render", at=@At(value="INVOKE", target = "Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;renderShadow(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/entity/Entity;FFLnet/minecraft/world/level/LevelReader;F)V"), index=6)
    private float newShadowSize(PoseStack pMatrixStack, MultiBufferSource pBuffer, Entity pEntity, float pWeight, float pPartialTicks, LevelReader pLevel, float pSize){
        float scaleMod = SizeUtility.getScale(pEntity);
        return pSize*scaleMod;
    }

    /*
    //Offset the player's render when standing on a snow covered block, soul sand, or farm block.  This is to prevent camera clipping through geometry when smol
    //@ModifyArg(method="render", at=@At(value="INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(DDD)V"), index = 1)
    @ModifyVariable(method="render", ordinal = 1, at=@At("LOAD"))
    public double renderYOffset(double d3, Entity entity, double pX, double pY, double pZ, float pRotationYaw, float pPartialTicks){
        if(entity instanceof LivingEntity livingEntity && SizeUtility.getScale(livingEntity) < 0.25F){
            double yOffset=0.0D;
            if(entity.level.getBlockState(entity.getOnPos().above()).is(Blocks.SNOW)){
                int layers = entity.level.getBlockState(entity.getOnPos().above()).getValue(SnowLayerBlock.LAYERS);
                yOffset = (0.125D*(1+layers));   //Offset the player render to put them above the snow
                //TODO fix this causing the player to skyrocket out of whack when at super smol sizes.  d3 seems to be based off of a delta to center center
            } else if(entity.level.getBlockState(entity.getOnPos()).is(Blocks.SNOW)){
                int layers = entity.level.getBlockState(entity.getOnPos()).getValue(SnowLayerBlock.LAYERS);
                yOffset = (0.125D*(1+layers));   //Offset the player render to put them above the snow
            }
            else if(entity.level.getBlockState(entity.getOnPos()).is(Blocks.SOUL_SAND)){
                yOffset = 0.125D;   //will need to test if this is the correct offset
            }
            System.out.println("pY: " + pY + "d3: " + d3 + " vec3.y: " + (d3-pY) + " d3+0.125D: " + d3+yOffset);
            return d3+yOffset;
        }
        return d3;
    }
*/
/*  //This is likely not required since we're changing shadow size above
    @ModifyVariable(method = "render", ordinal = 0, at = @At("STORE"))
    double doRenderShadowAndFire(double d1, Entity entity, double x, double y, double z, float yaw, float partialTicks) {
        return d1 / (entity.getBbHeight()/1.78D);
    }*/
}
