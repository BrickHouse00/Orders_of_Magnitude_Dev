package net.brickhouse.ordersofmagnitude.networking.packet;

import net.brickhouse.ordersofmagnitude.sizechange.SizeChangeCapability;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class MenuSizeSelectC2SPacket {

    double newSelection;
    public MenuSizeSelectC2SPacket(double newValue) {
        this.newSelection = newValue;
    }

    public static void encoder(MenuSizeSelectC2SPacket message, FriendlyByteBuf buffer) {
        // Write to buffer
        buffer.writeDouble(message.newSelection);
    }

    public static MenuSizeSelectC2SPacket decoder(FriendlyByteBuf buffer) {
        // Create packet from buffer data
        return new MenuSizeSelectC2SPacket(buffer.readDouble());
    }
    public void handle(Supplier<NetworkEvent.Context> supplier)
    {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Server execution
            ServerPlayer player = supplier.get().getSender();
            ServerLevel level = player.getLevel();
            ItemStack tablet = player.getMainHandItem();
            /*CompoundTag nbt = new CompoundTag();
            nbt.putDouble("targetScale", newSelection);
            tablet.setTag(nbt);*/
            tablet.getOrCreateTag().putDouble("targetScale", newSelection);
            System.out.print("MenuSizeSelectC2SPacket hasTag: " + tablet.hasTag() + "\n");
            //TODO remove the capability call.  Will be removing selected scale variable
            player.getCapability(SizeChangeCapability.INSTANCE).ifPresent(sizeChange ->
            {
                sizeChange.setSelectedScale(newSelection); //all this just to update a value

            });

        });
        context.setPacketHandled(true);
    }
}
