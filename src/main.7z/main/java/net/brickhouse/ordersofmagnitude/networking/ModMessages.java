package net.brickhouse.ordersofmagnitude.networking;

import net.brickhouse.ordersofmagnitude.OrdersOfMagnitude;
import net.brickhouse.ordersofmagnitude.networking.packet.*;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class ModMessages {
    private static SimpleChannel INSTANCE;

    private static int packetId = 0;

    private static int id() {
        return packetId++;
    }

    public static void register() {
        SimpleChannel net = NetworkRegistry.ChannelBuilder
                .named(new ResourceLocation(OrdersOfMagnitude.MOD_ID, "main_channel"))
                .networkProtocolVersion(() -> "1.0")
                .clientAcceptedVersions(s -> true)
                .serverAcceptedVersions(WS -> true)
                .simpleChannel();

        INSTANCE = net;

        /*net.messageBuilder(ChangeSizeC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .decoder(ChangeSizeC2SPacket::new)
                .encoder(ChangeSizeC2SPacket::toBytes)
                .consumer(ChangeSizeC2SPacket::handle)
                .add();*/

        /*net.messageBuilder(ChangeSizeS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .decoder(ChangeSizeS2CPacket::decoder)
                .encoder(ChangeSizeS2CPacket::encoder)
                .consumer(ChangeSizeS2CPacket::handle)
                .add();*/
        registerMessage(ChangeSizeC2SPacket.class, ChangeSizeC2SPacket::encoder, ChangeSizeC2SPacket::decoder, ChangeSizeC2SPacket::handle);
        registerMessage(ChangeSizeS2CPacket.class, ChangeSizeS2CPacket::encoder, ChangeSizeS2CPacket::decoder, ChangeSizeS2CPacket::handle);
        registerMessage(MenuSizeSelectC2SPacket.class, MenuSizeSelectC2SPacket::encoder, MenuSizeSelectC2SPacket::decoder, MenuSizeSelectC2SPacket::handle);
        registerMessage(MenuInfusionSelectC2SPacket.class, MenuInfusionSelectC2SPacket::encoder, MenuInfusionSelectC2SPacket::decoder, MenuInfusionSelectC2SPacket::handle);
        //registerMessage(InfusionEnergySyncS2CPacket.class, InfusionEnergySyncS2CPacket::encoder, InfusionEnergySyncS2CPacket::decoder, InfusionEnergySyncS2CPacket::handle);
        //registerMessage(InfusionFluidSyncS2CPacket.class, InfusionFluidSyncS2CPacket::encoder, InfusionFluidSyncS2CPacket::decoder, InfusionFluidSyncS2CPacket::handle);
        registerMessage(OMBlockEntityEnergySyncS2CPacket.class, OMBlockEntityEnergySyncS2CPacket::encoder, OMBlockEntityEnergySyncS2CPacket::decoder, OMBlockEntityEnergySyncS2CPacket::handle);
        registerMessage(OMBlockEntityFluidSyncS2CPacket.class, OMBlockEntityFluidSyncS2CPacket::encoder, OMBlockEntityFluidSyncS2CPacket::decoder, OMBlockEntityFluidSyncS2CPacket::handle);
    }

    public static void sendToServer(Object message) {
        INSTANCE.sendToServer(message);
    }

    public static void sendToClients(Object message){INSTANCE.send(PacketDistributor.ALL.noArg(), message);}

    private static <MSG> void registerMessage(Class<MSG> type, BiConsumer<MSG, FriendlyByteBuf> encoder, Function<FriendlyByteBuf, MSG> decoder, BiConsumer<MSG, Supplier<NetworkEvent.Context>> consumer)
    {
        INSTANCE.registerMessage(id(), type, encoder, decoder, consumer);
    }
    public static void send(PacketDistributor.PacketTarget target, ChangeSizeS2CPacket message)
    {
        /*if(Sender.level.isClientSide())
        {
            Sender.sendMessage(new TextComponent("Send client side"), Sender.getUUID());
        } else {
            Sender.sendMessage(new TextComponent("Send server side"), Sender.getUUID());
        }*/
        //send is a server to client function
        INSTANCE.send(target, message);  //this is failing because it can't be sent by the client.  test above says this is sent server side
    }
    /*private static final String PROTOCOL_VERSION = Integer.toString(1);
    private static final SimpleChannel HANDLER = NetworkRegistry.ChannelBuilder
            .named(new ResourceLocation(OrdersOfMagnitude.MOD_ID, "main_channel"))
            .clientAcceptedVersions(PROTOCOL_VERSION::equals)
            .serverAcceptedVersions(PROTOCOL_VERSION::equals)
            .networkProtocolVersion(() -> PROTOCOL_VERSION)
            .simpleChannel();

    private static int index;

    public static void register()
    {
        registerMessage(ChangeSizeC2SPacket.class, ChangeSizeC2SPacket::encoder, ChangeSizeC2SPacket::decoder, ChangeSizeC2SPacket::handle);
    }

    private static <MSG> void registerMessage(Class<MSG> type, BiConsumer<MSG, FriendlyByteBuf> encoder, Function<FriendlyByteBuf, MSG> decoder, BiConsumer<MSG, Supplier<NetworkEvent.Context>> consumer)
    {
        HANDLER.registerMessage(index++, type, encoder, decoder, consumer);
    }

    public static void sendToServer(Object msg)
    {
        HANDLER.sendToServer(msg);
    }

    public static void sendToPlayer(PacketDistributor.PacketTarget target, ChangeSizeC2SPacket message)
    {
        HANDLER.send(target, message);
    }*/
}
