package net.brickhouse.ordersofmagnitude.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class MixinPlayer {
/*
    //This didn't fix my issue either
    @Inject(at = @At("RETURN"), method = "getDimensions", cancellable = true)
    private void pehkui$getDimensions(Pose pPose, CallbackInfoReturnable<EntityDimensions> info)
    {
        Player player = Minecraft.getInstance().player;
        info.setReturnValue(info.getReturnValue().scale( player.getBbHeight()/1.8F));
    }*/
}
