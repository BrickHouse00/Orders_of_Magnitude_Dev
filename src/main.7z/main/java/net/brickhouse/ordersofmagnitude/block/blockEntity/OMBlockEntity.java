package net.brickhouse.ordersofmagnitude.block.blockEntity;

import net.brickhouse.ordersofmagnitude.energy.OMEnergy;
import net.brickhouse.ordersofmagnitude.fluid.ModFluids;
import net.brickhouse.ordersofmagnitude.fluid.OMFluidTank;
import net.brickhouse.ordersofmagnitude.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.fluids.FluidAttributes;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler.FluidAction;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.annotation.Nonnull;

public class OMBlockEntity extends BlockEntity implements MenuProvider {


    public OMBlockEntity(BlockEntityType<?> pType, BlockPos pPos, BlockState pBlockState, ForgeConfigSpec.ConfigValue<Integer> pEnergyConfig, ForgeConfigSpec.ConfigValue<Integer> pFluidConfig, int pInvSize, boolean pTankAcceptExternal) {
        super(pType, pPos, pBlockState);
        ENERGY_STORAGE = new OMEnergy(pEnergyConfig.get(), 256) {
            @Override
            public void onEnergyChanged() {
                changedEnergy();
            }
        };

        FLUID_TANK = new OMFluidTank(pFluidConfig.get()){
            @Override
            protected void onContentsChanged(){
                changedFluid();
            }
        };

        itemHandler = new ItemStackHandler(pInvSize);

        data = new ContainerData() {
            @Override
            public int get(int pIndex) {
                return dataGet(pIndex);
            }

            @Override
            public void set(int pIndex, int pValue) {
                dataSet(pIndex, pValue);
            }

            @Override
            public int getCount() {
                return dataGetCount();
            }
        };
        this.FLUID_TANK.setCanAcceptExternal(pTankAcceptExternal);
    }

    protected final ContainerData data;
    public final ItemStackHandler itemHandler;

    public final OMEnergy ENERGY_STORAGE;

    public final OMFluidTank FLUID_TANK;
    private int progress = 0;
    private int maxProgress = 80;

    public LazyOptional<IEnergyStorage> lazyEnergyStorage = LazyOptional.empty();
    public LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();
    public LazyOptional<IFluidHandler> lazyFluidHandler = LazyOptional.empty();

    public void changedEnergy(){
        setChanged();
    }

    public void changedFluid(){
        setChanged();
    }

    public int dataGet(int pIndex){
        return 0;
    }

    public void dataSet(int pIndex, int pValue){

    }

    public int dataGetCount(){
        return 0;
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> capability, @javax.annotation.Nullable Direction facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return lazyItemHandler.cast();
        }
        if (capability == CapabilityEnergy.ENERGY){
            return lazyEnergyStorage.cast();
        }

        if(capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY) {
            //System.out.println("cap: " + capability + " name: " + capability.getName() + " direction: " + facing);
            return lazyFluidHandler.cast();
        }

        return super.getCapability(capability, facing);
    }

    public void setProgress(int pValue){
        progress = pValue;
    }

    public int getProgress(){
        return progress;
    }

    public void resetProgress(){
        progress = 0;
    }

    public void setMaxProgress(int pValue){
        maxProgress = pValue;
    }

    public int getMaxProgress(){
        return maxProgress;
    }

    public static boolean hasEnoughEnergy(OMBlockEntity pBlockEntity, OMEnergy pEnergyStorage, ForgeConfigSpec.ConfigValue<Integer> pConfig){

        return pEnergyStorage.getEnergyStored() >= pConfig.get();
    }
    public static void extractEnergy(OMBlockEntity pBlockEntity, OMEnergy pEnergyStorage, ForgeConfigSpec.ConfigValue<Integer> pConfig, boolean pSimulate){
        pEnergyStorage.extractEnergy(pConfig.get(), pSimulate);
    }

    public void setEnergyLevel(int energy) {
        this.ENERGY_STORAGE.setEnergy(energy);
    }

    public OMEnergy getEnergyStorage() {
        return this.ENERGY_STORAGE;
    }

    public void setFluid(FluidStack stack) {
        this.FLUID_TANK.setFluid(stack);
    }

    public FluidStack getFluidStack() {
        return this.FLUID_TANK.getFluid();
    }

    public static void tryOutputFluid(FluidTank pFluidTank, Level pLevel, BlockPos pBlockPos, @javax.annotation.Nullable Direction pSide, FluidStack pFluidStack){
        if(!pLevel.isClientSide() && pFluidTank.getFluidAmount() > 0){
            for (Direction direction: Direction.values()){              //test all sides for a valid fluid pipe
                BlockEntity adjacentEntity = pLevel.getBlockEntity(pBlockPos.relative(direction));      //grab the entity
                if(adjacentEntity != null){
                    //System.out.println("tryOutputFluid: adjacententity " + adjacentEntity.toString());
                    //System.out.println("found an entity " + direction.toString() + " of the mixer.");
                    //We have an entity.  Create a fresh fluidstack and check if the entity can handle fluids
                    FluidStack outputStack = new FluidStack(pFluidStack, pFluidTank.getFluidAmount());
                    adjacentEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, direction.getOpposite()).map(outputHandler -> {
                        int simulateFill = outputHandler.fill(outputStack, FluidAction.SIMULATE);

                        //System.out.println("simulateFill " + simulateFill + " outputHandler tank capacity: " + outputHandler.getTankCapacity(0) + " outputHandler tank amount: " + outputHandler.getFluidInTank(0).getAmount());
                        if(simulateFill > 0) {
                            int fluidOut = outputHandler.fill(new FluidStack(outputStack, simulateFill), FluidAction.EXECUTE);
                            pFluidTank.drain(fluidOut, FluidAction.EXECUTE);
                            return true;
                        }
                        return false;
                    });
                }
            }
        }

    }

    public void transferItemFluidToFluidTank(OMBlockEntity pEntity, int pSlotIn, int pSlotOut) {
        pEntity.itemHandler.getStackInSlot(pSlotIn).getCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY).ifPresent(handler -> {
            int drainAmount = Math.min(pEntity.FLUID_TANK.getSpace(), FluidAttributes.BUCKET_VOLUME);

            FluidStack stack = handler.drain(drainAmount, IFluidHandler.FluidAction.SIMULATE);
            if(pEntity.FLUID_TANK.isFluidValid(stack)) {
                stack = handler.drain(drainAmount, IFluidHandler.FluidAction.EXECUTE);
                //fillTankWithFluid(pEntity, stack, handler.getContainer());
                fillTankWithFluid(pEntity, pEntity.FLUID_TANK, stack, pEntity.itemHandler, handler.getContainer(), pSlotIn, pSlotOut, 1, IFluidHandler.FluidAction.EXECUTE, false);
            }
        });
    }

    public void transferFluidTanktoItemFluid(OMBlockEntity pEntity, int pSlotIn, int pSlotOut){
        pEntity.itemHandler.getStackInSlot(pSlotIn).getCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY).ifPresent((handler -> {
            if(pEntity.FLUID_TANK.getFluid().getAmount() > FluidAttributes.BUCKET_VOLUME){
                FluidStack fluidStack = new FluidStack(pEntity.FLUID_TANK.getFluid(), FluidAttributes.BUCKET_VOLUME);
                fillBucketWithFluid(pEntity.FLUID_TANK, fluidStack, pEntity.itemHandler, pSlotIn, pSlotOut, 1, IFluidHandler.FluidAction.EXECUTE, false);
            }
        }));
    }

    public static boolean hasEnoughFluid(OMBlockEntity pBlockEntity, OMFluidTank pFluidTank, ForgeConfigSpec.ConfigValue<Integer> pConfig){
        return pFluidTank.getFluidAmount() >= pConfig.get();
    }

    public static void drainFluid(OMBlockEntity pBlockEntity, OMFluidTank pFluidTank, ForgeConfigSpec.ConfigValue<Integer> pConfig, FluidAction pAction){
        pFluidTank.drain(pConfig.get(), pAction);
    }

    public static void fillFluid(OMBlockEntity pBlockEntity, OMFluidTank pFluidTank, FluidStack pResource, ForgeConfigSpec.ConfigValue<Integer> pConfig, FluidAction pAction){
        pFluidTank.fillInternal(pResource, pAction);
    }

    public static void fillTankWithFluid(OMBlockEntity pEntity, OMFluidTank pFluidTank, FluidStack stack, ItemStackHandler pItemHandler, ItemStack pContainer, int pSlotIn, int pSlotOut, int pAmount, FluidAction pAction, boolean pSimulate){
        pFluidTank.fillInternal(stack, pAction);

        pItemHandler.extractItem(pSlotIn, pAmount, pSimulate);   //Remove the filled bucket
        pItemHandler.insertItem(pSlotOut, pContainer, pSimulate);    //add empty bucket?  Not sure TBH
    }

    public static void fillBucketWithFluid(OMFluidTank pFluidTank, FluidStack pFluidStack, ItemStackHandler pItemHandler, int pSlotIn, int pSlotOut, int pAmount, FluidAction pAction, boolean pSimulate){
        ItemStack filledBucket = new ItemStack(ModItems.REALLOCATING_BUCKET.get());
        pItemHandler.extractItem(pSlotIn, pAmount, pSimulate);
        pFluidTank.drain(pFluidStack, pAction);
        pItemHandler.insertItem(pSlotOut, filledBucket, pSimulate);
    }

    public void drops() {
        SimpleContainer inventory = new SimpleContainer(itemHandler.getSlots());
        for (int i = 0; i < itemHandler.getSlots(); i++) {
            inventory.setItem(i, itemHandler.getStackInSlot(i));
        }
        Containers.dropContents(this.level, this.worldPosition, inventory);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
        lazyEnergyStorage = LazyOptional.of(()-> ENERGY_STORAGE);
        lazyFluidHandler = LazyOptional.of(() -> FLUID_TANK);
    }

    @Override
    public void invalidateCaps()  {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
        lazyEnergyStorage.invalidate();
        lazyFluidHandler.invalidate();
    }

    @Override
    protected void saveAdditional(@NotNull CompoundTag tag) {
        tag.put("inventory", itemHandler.serializeNBT());
        tag.putInt("energy", ENERGY_STORAGE.getEnergyStored());
        tag = FLUID_TANK.writeToNBT(tag);
        super.saveAdditional(tag);
    }

    @Override
    public void load(CompoundTag nbt) {
        super.load(nbt);
        itemHandler.deserializeNBT(nbt.getCompound("inventory"));
        ENERGY_STORAGE.setEnergy(nbt.getInt("energy"));
        FLUID_TANK.readFromNBT(nbt);
    }

    @Override
    public Component getDisplayName() {
        return null;
    }



    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int pContainerId, Inventory pPlayerInventory, Player pPlayer) {
        return null;
    }
}
