package net.brickhouse.ordersofmagnitude.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.brickhouse.ordersofmagnitude.OrdersOfMagnitude;
import net.brickhouse.ordersofmagnitude.client.MatterReallocatorTabletMenu;
import net.brickhouse.ordersofmagnitude.client.gui.elements.TabletButton;
import net.brickhouse.ordersofmagnitude.item.custom.MatterReallocatorTabletItem;
import net.brickhouse.ordersofmagnitude.networking.ModMessages;
import net.brickhouse.ordersofmagnitude.networking.packet.MenuSizeSelectC2SPacket;
import net.brickhouse.ordersofmagnitude.sizechange.SizeChangeCapability;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class MatterReallocatorTabletScreen extends AbstractContainerScreen<MatterReallocatorTabletMenu>{
    private static ResourceLocation texture_path;

    private int numSlots;
    private int BUTTON_LEFT_JUSTIFICATION = 27;
    private int BUTTON_TOP_JUSTIFICATION = -18;
    private int BUTTON_WIDGET_HEIGHT = 22;
    private int BUTTON_WIDGET_WIDTH = 80;
    private double targetScale;


    public MatterReallocatorTabletScreen(MatterReallocatorTabletMenu pMenu, Inventory pPlayerInventory, Component pTitle) {
        super(pMenu, pPlayerInventory, pTitle);
        if(Minecraft.getInstance().player.getMainHandItem().getItem() instanceof MatterReallocatorTabletItem tablet) {
            texture_path = new ResourceLocation(OrdersOfMagnitude.MOD_ID, tablet.TEXTURE_PATH);
            numSlots = tablet.NUM_SLOTS;
        } else {
            System.out.print("Nothing was returned in main hand\n");
        }
    }


    @Override
    protected void init() {
        super.init();
        //leftPos = (width - imageWidth) / 2;
        //topPos = (height - imageHeight) / 2;
        //Minecraft.getInstance().player.getCapability(SizeChangeCapability.INSTANCE).ifPresent(sizeChange -> {targetScale = sizeChange.getSelectedScale();}); //This will be changed out for the item capability
        Player player = Minecraft.getInstance().player;
        if(player != null && player.getMainHandItem().hasTag()){
            targetScale = player.getMainHandItem().getTag().getDouble("targetScale");
        } else {
            targetScale = 1.0;
        }

        //UpdateButtonWidgets();
        RefreshButtons();
    }

    protected void RefreshButtons(){
        if(this.menu.slots.size() > 35) { //Skip the player inventory and hotbar
            int invSlotCount = 36;
            double oldTargetScale = targetScale;
            targetScale = 1.0;  //we want to clear the targetScale to prevent the player from unequipping a module and then being able to use the resize
            for(int j = 0; j < 2; j++){
                for(int i = 0; i < numSlots/2; i++){
                    Slot slot = this.menu.slots.get(invSlotCount);
                    ItemStack itemStack = slot.getItem();
                    if(itemStack.hasTag()) {
                        double designScale = itemStack.getTag().getDouble("designScale");
                        System.out.println("Button text: " + designScale);
                        AddButtonWidget(leftPos + BUTTON_LEFT_JUSTIFICATION + j * BUTTON_WIDGET_WIDTH,
                                topPos + BUTTON_TOP_JUSTIFICATION + i * BUTTON_WIDGET_HEIGHT,
                                40,
                                20,
                                new TextComponent(String.valueOf(designScale*100D)+"%"),
                                button -> {onButtonSetTarget(designScale);}
                        );
                        if(designScale == oldTargetScale){      //here's where we check the tablet for the old selection.  If the selection still exists in the updated list, we set it back to the target
                            targetScale = designScale;
                        }
                    } else {
                        AddButtonWidget(leftPos + BUTTON_LEFT_JUSTIFICATION + j * BUTTON_WIDGET_WIDTH,
                                topPos + BUTTON_TOP_JUSTIFICATION + i * BUTTON_WIDGET_HEIGHT,
                                40,
                                20,
                                new TextComponent("None"),
                                button -> {onButtonSetNoTarget();}
                        );
                    }
                    invSlotCount++;
                }
            }
        }
    }

    protected void AddButtonWidget(int xPos, int yPos, int width, int height, Component message, Button.OnPress buttonResult){
        TabletButton buttonToAdd = new TabletButton(xPos, yPos, width, height, message, buttonResult);
        addRenderableWidget(buttonToAdd);
    }

    private void onButtonSetNoTarget(){
        //place holder since you can't pass a null to the button field of widget
    }

    private void onButtonSetTarget(double newTarget){
        Player player = Minecraft.getInstance().player;
        //player.getCapability(MyCapability.INSTANCE).ifPresent(sizeChange -> sizeChange.setSelectedScale(newTarget));
        targetScale = newTarget;
        player.sendMessage(new TextComponent("Selected scale of " + newTarget), player.getUUID());
    }

    @Override
    protected void slotClicked(Slot pSlot, int pSlotId, int pMouseButton, ClickType pType) {
        super.slotClicked(pSlot, pSlotId, pMouseButton, pType);
        if(pSlotId > 35)
        {
            clearWidgets();
            RefreshButtons();
        }
        System.out.print("slotClicked: pSlotID: " + pSlotId + " pType: " + pType + "\n");
    }

    @Override
    public void onClose()
    {
        super.onClose();
        if(Minecraft.getInstance().player == null){ return;}
        //ItemStack tablet = Minecraft.getInstance().player.getMainHandItem();
        /*CompoundTag nbt = new CompoundTag();
        nbt.putDouble("targetScale", targetScale);
        tablet.setTag(nbt);*/
        //tablet.getOrCreateTag().putDouble("targetScale", targetScale);
        //System.out.print("TabletGui hasTag: " + tablet.hasTag() + "\n");
        ModMessages.sendToServer(new MenuSizeSelectC2SPacket(targetScale));
    }

    @Override
    protected void renderBg(PoseStack pPoseStack, float pPartialTick, int pMouseX, int pMouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, texture_path);
        //int x = (width - imageWidth) / 2;
        //int y = (height - imageHeight) / 2 - 30;
        int x = this.leftPos;
        int y = this.topPos-30;

        this.blit(pPoseStack, x, y, 0, 0, 176, 222);//imageWidth, imageHeight);
        renderLights(pPoseStack);
    }

    @Override
    protected void renderLabels(PoseStack pPoseStack, int pMouseX, int pMouseY) {
        //this.inventoryLabelX = leftPos+5;
        //this.inventoryLabelY = 100;
        //font.draw(pPoseStack, this.playerInventoryTitle, (float)this.inventoryLabelX, (float)this.inventoryLabelY, 9145227);
        //TODO fix the double drawing of this text.  It's showing Inventory off to the side for whatever reason
    }

    @Override
    public void render(PoseStack pPoseStack, int mouseX, int mouseY, float delta) {
        renderBackground(pPoseStack);
        super.render(pPoseStack, mouseX, mouseY, delta);

        renderLabels(pPoseStack, mouseX, mouseY);
        renderTooltip(pPoseStack, mouseX, mouseY);
    }

    public void renderLights(PoseStack pPoseStack){
        int invSlotCount = 36;
        int i = this.leftPos;
        int j = this.topPos-30;
        int xOffset = 230;
        int yOffset = 6;
        for(int k = 0; k < 2; k++) {
            for (int m = 0; m < numSlots / 2; m++) {
                Slot slot = this.menu.slots.get(invSlotCount);
                ItemStack itemStack = slot.getItem();
                if(itemStack.hasTag()){
                    double designScale = itemStack.getTag().getDouble("designScale");
                    if(designScale == targetScale){
                        xOffset = 198;
                    }
                }
                invSlotCount++;
                this.blit(pPoseStack, i+10+(80*k), j+14+(23*m), xOffset, yOffset, 15, 15);
                xOffset = 230; //reset the offset
            }
        }
    }

}
