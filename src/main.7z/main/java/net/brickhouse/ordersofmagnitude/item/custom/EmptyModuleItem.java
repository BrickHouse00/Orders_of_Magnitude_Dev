package net.brickhouse.ordersofmagnitude.item.custom;

import net.minecraft.world.item.Item;

public class EmptyModuleItem extends Item {
    public EmptyModuleItem(Properties pProperties) {
        super(pProperties);
    }
}
