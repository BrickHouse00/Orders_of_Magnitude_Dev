package net.brickhouse.ordersofmagnitude.client.gui.elements;

import net.brickhouse.ordersofmagnitude.item.custom.InfusedModuleItem;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class TabletSlot extends SlotItemHandler {


    public TabletSlot(IItemHandler itemHandler, int pSlot, int pX, int pY) {
        super(itemHandler, pSlot, pX, pY);
    }

    @Override
    public boolean mayPlace(ItemStack itemStack){
        return !itemStack.isEmpty() && itemStack.getItem() instanceof InfusedModuleItem;
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }
}
