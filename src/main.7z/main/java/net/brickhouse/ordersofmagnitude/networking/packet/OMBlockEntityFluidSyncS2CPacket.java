package net.brickhouse.ordersofmagnitude.networking.packet;

import net.brickhouse.ordersofmagnitude.block.blockEntity.MatterInfusionBlockEntity;
import net.brickhouse.ordersofmagnitude.block.blockEntity.OMBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OMBlockEntityFluidSyncS2CPacket {

    private final FluidStack fluidStack;
    private final BlockPos blockPos;
    public OMBlockEntityFluidSyncS2CPacket(FluidStack pFluidStack, BlockPos pBlockPos) {
        this.fluidStack = pFluidStack;
        this.blockPos = pBlockPos;
    }

    public static void encoder(OMBlockEntityFluidSyncS2CPacket message, FriendlyByteBuf buffer) {
        // Write to buffer
        buffer.writeFluidStack(message.fluidStack);
        buffer.writeBlockPos(message.blockPos);
    }

    public static OMBlockEntityFluidSyncS2CPacket decoder(FriendlyByteBuf buffer) {
        // Create packet from buffer data
        return new OMBlockEntityFluidSyncS2CPacket(buffer.readFluidStack(), buffer.readBlockPos());
    }
    public void handle(Supplier<NetworkEvent.Context> supplier)
    {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Client execution
            if(Minecraft.getInstance().level.getBlockEntity(blockPos) instanceof OMBlockEntity omBlockEntity){
                omBlockEntity.setFluid(fluidStack);
                //if(Minecraft.getInstance().player.containerMenu instanceof MatterInfusionMenu menu && menu.getBlockEntity().getBlockPos().equals(blockPos)){
                //    matterInfusionBlockEntity.setFluid(fluidStack);
                //}

            }

        });
        context.setPacketHandled(true);
    }
}
