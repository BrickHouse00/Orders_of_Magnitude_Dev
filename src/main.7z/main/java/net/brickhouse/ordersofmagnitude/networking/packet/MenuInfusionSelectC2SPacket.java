package net.brickhouse.ordersofmagnitude.networking.packet;

import net.brickhouse.ordersofmagnitude.client.MatterInfusionMenu;
import net.brickhouse.ordersofmagnitude.item.ModItems;
import net.brickhouse.ordersofmagnitude.sizechange.SizeChangeCapability;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class MenuInfusionSelectC2SPacket {

    double newScale;
    BlockPos blockPos;
    public MenuInfusionSelectC2SPacket(double newValue) {
        this.newScale = newValue;
    }

    public static void encoder(MenuInfusionSelectC2SPacket message, FriendlyByteBuf buffer) {
        // Write to buffer
        buffer.writeDouble(message.newScale);
    }

    public static MenuInfusionSelectC2SPacket decoder(FriendlyByteBuf buffer) {
        // Create packet from buffer data
        return new MenuInfusionSelectC2SPacket(buffer.readDouble());
    }
    public void handle(Supplier<NetworkEvent.Context> supplier)
    {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Server execution
            ServerPlayer player = supplier.get().getSender();
            ServerLevel level = player.getLevel();

            if(player.containerMenu instanceof MatterInfusionMenu){
                ((MatterInfusionMenu) player.containerMenu).updateDesignScale(newScale);
            }
            /*ItemStack newItem = new ItemStack(ModItems.INFUSED_MODULE.get());
            CompoundTag nbt = new CompoundTag();

            nbt.putDouble("designScale", newScale);
            newItem.setTag(nbt);
            player.getInventory().add(newItem);
            System.out.print("MenuInfusionSelectC2SPacket added " + newItem + " to " + player + "\n");*/

            //TODO remove the capability call.  Will be removing selected scale variable

        });
        context.setPacketHandled(true);
    }
}
