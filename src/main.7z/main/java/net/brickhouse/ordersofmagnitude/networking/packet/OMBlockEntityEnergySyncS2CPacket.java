package net.brickhouse.ordersofmagnitude.networking.packet;

import net.brickhouse.ordersofmagnitude.block.blockEntity.OMBlockEntity;
import net.brickhouse.ordersofmagnitude.client.MatterInfusionMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OMBlockEntityEnergySyncS2CPacket {

    private final int energy;
    private final BlockPos blockPos;
    public OMBlockEntityEnergySyncS2CPacket(int pEnergy, BlockPos pBlockPos) {
        this.energy = pEnergy;
        this.blockPos = pBlockPos;
    }

    public static void encoder(OMBlockEntityEnergySyncS2CPacket message, FriendlyByteBuf buffer) {
        // Write to buffer
        buffer.writeInt(message.energy);
        buffer.writeBlockPos(message.blockPos);
    }

    public static OMBlockEntityEnergySyncS2CPacket decoder(FriendlyByteBuf buffer) {
        // Create packet from buffer data
        return new OMBlockEntityEnergySyncS2CPacket(buffer.readInt(), buffer.readBlockPos());
    }
    public void handle(Supplier<NetworkEvent.Context> supplier)
    {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Client execution
            if(Minecraft.getInstance().level.getBlockEntity(blockPos) instanceof OMBlockEntity omBlockEntity){
                omBlockEntity.setEnergyLevel(energy);
                if(Minecraft.getInstance().player.containerMenu instanceof MatterInfusionMenu menu && menu.getBlockEntity().getBlockPos().equals(blockPos)){
                    omBlockEntity.setEnergyLevel(energy);
                }

            }

        });
        context.setPacketHandled(true);
    }
}
