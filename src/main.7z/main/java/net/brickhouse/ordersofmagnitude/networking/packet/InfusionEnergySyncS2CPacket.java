package net.brickhouse.ordersofmagnitude.networking.packet;

import net.brickhouse.ordersofmagnitude.block.blockEntity.MatterInfusionBlockEntity;
import net.brickhouse.ordersofmagnitude.client.MatterInfusionMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class InfusionEnergySyncS2CPacket {

    private final int energy;
    private final BlockPos blockPos;
    public InfusionEnergySyncS2CPacket(int pEnergy, BlockPos pBlockPos) {
        this.energy = pEnergy;
        this.blockPos = pBlockPos;
    }

    public static void encoder(InfusionEnergySyncS2CPacket message, FriendlyByteBuf buffer) {
        // Write to buffer
        buffer.writeInt(message.energy);
        buffer.writeBlockPos(message.blockPos);
    }

    public static InfusionEnergySyncS2CPacket decoder(FriendlyByteBuf buffer) {
        // Create packet from buffer data
        return new InfusionEnergySyncS2CPacket(buffer.readInt(), buffer.readBlockPos());
    }
    public void handle(Supplier<NetworkEvent.Context> supplier)
    {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Client execution
            if(Minecraft.getInstance().level.getBlockEntity(blockPos) instanceof MatterInfusionBlockEntity matterInfusionBlockEntity){
                matterInfusionBlockEntity.setEnergyLevel(energy);
                if(Minecraft.getInstance().player.containerMenu instanceof MatterInfusionMenu menu && menu.getBlockEntity().getBlockPos().equals(blockPos)){
                    matterInfusionBlockEntity.setEnergyLevel(energy);
                }

            }

        });
        context.setPacketHandled(true);
    }
}
